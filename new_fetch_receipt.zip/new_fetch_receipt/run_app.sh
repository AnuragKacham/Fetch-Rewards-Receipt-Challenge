#!/bin/bash
docker run --name receipts-processor -p 8080:8080 -d receipts-processor
